import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

class Game{
	private int agk1;
	private int agk2;
	private int hasil;
	private int score;
	private String temp;
	public Game() {
		agk1 = 0;
		agk2 = 0;
		hasil = 0;
		score = 0;
	}
	
	public int RandomOperasiMatematika() {
        Random rand = new Random();
        if(rand.nextBoolean()) {
            temp="-";
            return -1;
        }
        else {
            temp="+";
            return 1;
        }
    }
	public String pertanyaan() {
		agk1 = randomAngka();
		agk2 = randomAngka();
		hasil = agk1 + agk2 * RandomOperasiMatematika();
	    return agk1 + " " + temp + " "+ agk2 + " = ?";
	}
	
	public int randomAngka() {
		return (int)(Math.random() * 100) + 1;
	}

	public int getHasil() {
		return hasil;
	}
	
	public void setScore(int hasil) {
		if(hasil == 1)score += 10;
		else score -= 5;
	}
	
	public int getScore() {
		return score;
	}
}


public class Perhitungan implements ActionListener{
	JFrame jf;

	Game gm;
	JLabel score;
	JLabel soal;
	JTextField hasil;
	JButton jb;
	
	JPanel panel1;
    JPanel panel2;
    JPanel panel3;
    JPanel panel4;
	
    
	public Perhitungan() {
		
		jf = new JFrame("Perhitungan");
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setSize(250,250);
        jf.setLayout(new GridLayout(4,2));
        jf.setLocationRelativeTo(null);
        
        gm = new Game();
		score = new JLabel();
		soal = new JLabel();
		hasil = new JTextField("",10);
		jb = new JButton("Submit");
		
		score.setText("Score : 0");
		soal.setText(gm.pertanyaan());
		
		panel1 = new JPanel();
        panel1.add(score);
        
        panel2 = new JPanel();
        panel2.add(soal);
        
        panel3 = new JPanel();
        panel3.add(hasil);
        
        panel4 = new JPanel();
        panel4.add(jb);
		
        jf.add(panel1);
        jf.add(panel2);
        jf.add(panel3);
        jf.add(panel4);
        
        jf.setVisible(true);
        jb.addActionListener(this);
	}
	

	public static void main(String[] args) {
		new Perhitungan();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(hasil.getText().length()==0) {
			JOptionPane.showMessageDialog(null, "hasil Tidak Boleh kosong");
		}
		else {
			int test = 0;
			try {
				int hasilInt = Integer.parseInt(hasil.getText());
			} catch (Exception e2) {
				test = 1;
				JOptionPane.showMessageDialog(null, "hasil Harus Berupa Angka!");
			}
			
			if(test==0) {
				if(Integer.parseInt(hasil.getText())  != gm.getHasil()) {
					JOptionPane.showMessageDialog(null, "hasil Anda Salah! -5 Poin");
					gm.setScore(0);
				}
				else {
					JOptionPane.showMessageDialog(null, "hasil Anda Benar! +10 Poin");
					gm.setScore(1);
				}
				score.setText("Score : " + Integer.toString(gm.getScore()));
				soal.setText(gm.pertanyaan());
			}
			hasil.setText("");
		}
	}
	
}
